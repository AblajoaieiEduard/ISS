package Entities;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.persistence.Entity;

@Entity
@Table ( name = "Sefi")
public class Sef extends Utilizator{

    public Sef(Integer id, String user, String parola) {
        super(id, user, parola);
    }

    public Sef(){

    }
    @Id
    @GeneratedValue( generator = "increment")
    @GenericGenerator( name="increment", strategy = "increment")
    public Integer getId(){
        return super.getId();
    }

    @Column( name= "nume")
    public String getUser(){
        return super.getUser();
    }

    public String getParola(){
        return super.getParola();
    }

    public void setId(Integer id){
        super.setId(id);
    }

    public void setUser(String user){
        super.setUser(user);
    }

    public void setParola(String parola){
        super.setParola(parola);
    }

}
