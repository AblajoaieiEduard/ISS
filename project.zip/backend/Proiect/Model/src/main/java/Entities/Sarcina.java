package Entities;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@javax.persistence.Entity
@Table( name = "Sarcini")
public class Sarcina  extends Entity<Integer>{
    StareSarcina stare;
    String descriere;
    Date deadline;
    Integer idSef;
    List<Integer> angajati;

    public Sarcina() {
        super(0);
        angajati = new ArrayList<Integer>();
    }

    public Sarcina(Integer id, StareSarcina stare, String descriere, Date deadline, Integer idSef) {
        super(id);
        this.idSef = idSef;
        this.stare = stare;
        this.descriere = descriere;
        this.deadline = deadline;
        angajati = new ArrayList<Integer>();

    }

    public Sarcina(Integer id,StareSarcina stare, String descriere, Date deadline, Integer idSef, List<Integer> angajati) {
        super(id);
        this.stare = stare;
        this.descriere = descriere;
        this.deadline = deadline;
        this.idSef = idSef;
        this.angajati = angajati;
    }



    public Integer getIdSef() {
        return idSef;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Sarcina sarcina = (Sarcina) o;
        return Objects.equals(getId(), sarcina.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.getId());
    }

    public void setIdSef(Integer idSef) {
        this.idSef = idSef;
    }

    @Transient
    public List<Integer> getAngajati() {
        return angajati;
    }

    public void setAngajati(List<Integer> angajati) {
        this.angajati = angajati;
    }

    @Enumerated(EnumType.STRING)
    public StareSarcina getStare() {
        return stare;
    }

    public void setStare(StareSarcina stare) {
        this.stare = stare;
    }

    public String getDescriere() {
        return descriere;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }

    @Temporal(TemporalType.TIMESTAMP)
    public Date getDeadline() {
        return deadline;
    }

    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    @Id
    @GeneratedValue( generator = "increment")
    @GenericGenerator( name="increment", strategy = "increment")
    public Integer getId(){
        return super.getId();
    }

    public void setId(Integer id){
        super.setId(id);
    }
}
