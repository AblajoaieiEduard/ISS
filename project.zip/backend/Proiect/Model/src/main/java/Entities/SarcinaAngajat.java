package Entities;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Objects;

@javax.persistence.Entity
@Table( name = "SarcinaAngajat")
public class SarcinaAngajat  extends Entity<Integer>{
    Integer idSarcina;
    Integer idAngajat;

    public SarcinaAngajat(Integer id,Integer idSarcina, Integer idAngajat) {
        super(id);
        this.idSarcina = idSarcina;
        this.idAngajat = idAngajat;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SarcinaAngajat that = (SarcinaAngajat) o;
        return Objects.equals(getId(), that.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId());
    }

    @Id
    @GeneratedValue( generator = "increment")
    @GenericGenerator( name="increment", strategy = "increment")
    public Integer getId(){
        return super.getId();
    }

    public void setId(Integer id){
        super.setId(id);
    }

    public SarcinaAngajat() {
        super(0);
    }

    @Column(name="sarcinaId")
    public Integer getIdSarcina() {
        return idSarcina;
    }

    public void setIdSarcina(Integer idSarcina) {
        this.idSarcina = idSarcina;
    }

    @Column(name="angajatId")
    public Integer getIdAngajat() {
        return idAngajat;
    }

    public void setIdAngajat(Integer idAngajat) {
        this.idAngajat = idAngajat;
    }
}
