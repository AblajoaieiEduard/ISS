package Entities;

public enum StareSarcina {
    ALOCATA,
    PROGRES,
    FINALIZATA
}
