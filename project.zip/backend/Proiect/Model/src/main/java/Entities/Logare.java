package Entities;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Objects;

public class Logare {
    public Integer id;
    public Integer idAngajat;
    public LocalDateTime dateTime;

    public Logare(){

    }


    @Temporal(TemporalType.TIMESTAMP)
    @Column( name="dataOra")
    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Logare logare = (Logare) o;
        return id.equals(logare.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Id
    @GeneratedValue(generator = "increment")
    @GenericGenerator(name="increment", strategy="increment")
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdAngajat() {
        return idAngajat;
    }

    public void setIdAngajat(Integer idAngajat) {
        this.idAngajat = idAngajat;
    }

    public Logare(Integer id, Integer idAngajat) {
        this.id = id;
        this.idAngajat = idAngajat;
        this.dateTime = LocalDateTime.now();
    }

    public Logare(Integer id, Integer idAngajat, LocalDateTime dateTime) {
        this.id = id;
        this.idAngajat = idAngajat;
        this.dateTime = dateTime;
    }
}
