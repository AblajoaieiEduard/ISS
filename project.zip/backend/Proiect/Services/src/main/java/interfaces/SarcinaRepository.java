package interfaces;

import Entities.Angajat;
import Entities.Sarcina;

public interface SarcinaRepository extends CrudRepository<Integer, Sarcina>{
}
