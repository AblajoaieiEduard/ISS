package interfaces;

import Entities.Angajat;

import java.util.List;

public interface AngajatRepository extends CrudRepository<Integer, Angajat>{
    public List<Angajat> findAngajat(String name);
}
