package interfaces;

import Entities.Angajat;
import Entities.SarcinaAngajat;

import java.util.List;

public interface SarcinaAngajatRepository extends CrudRepository<Integer, SarcinaAngajat> {
    public List<Integer> getAllForSarcina(Integer sarcinaId);

}
