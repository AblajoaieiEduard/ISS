package interfaces;

import Entities.Angajat;
import Entities.Sef;

import java.util.List;

public interface SefRepository extends CrudRepository<Integer, Sef>{
    public Sef findSef(String name);

}
