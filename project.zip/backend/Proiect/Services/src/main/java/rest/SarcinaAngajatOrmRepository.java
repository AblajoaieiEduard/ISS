package rest;

import Entities.Sarcina;
import Entities.SarcinaAngajat;
import interfaces.SarcinaAngajatRepository;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import java.util.List;
import java.util.stream.Collectors;

public class SarcinaAngajatOrmRepository implements SarcinaAngajatRepository {
    private static SessionFactory sessionFactory;

    static void initialize() {
        // A SessionFactory is set up once for an application!
        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .configure() // configures settings from hibernate.cfg.xml
                .build();
        try {
            sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
        }
        catch (Exception e) {
            System.err.println("Exceptie "+e);
            StandardServiceRegistryBuilder.destroy( registry );
        }
    }

    public SarcinaAngajatOrmRepository(){ initialize(); }

    static void close() {
        if ( sessionFactory != null ) {
            sessionFactory.close();
        }
    }

    @Override
    public List<Integer> getAllForSarcina(Integer sarcinaId) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                List<SarcinaAngajat> sarciniAngajati =
                        session.createNativeQuery("select SarcinaAngajat.* from SarcinaAngajat where sarcinaId="
                                + sarcinaId, SarcinaAngajat.class)
                                .list();
                tx.commit();
                return sarciniAngajati.stream().map(SarcinaAngajat::getIdAngajat).collect(Collectors.toList());
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
        return null;
    }

    @Override
    public SarcinaAngajat findOne(Integer integer) {
        return null;
    }

    @Override
    public List<SarcinaAngajat> findAll() {
        return null;
    }

    @Override
    public SarcinaAngajat save(SarcinaAngajat entity) {
        return null;
    }

    @Override
    public SarcinaAngajat delete(Integer integer) {
        return null;
    }

    @Override
    public SarcinaAngajat update(SarcinaAngajat entity) {
        return null;
    }

    @Override protected void finalize() throws Throwable {
        close();
        super.finalize();
    }
}
