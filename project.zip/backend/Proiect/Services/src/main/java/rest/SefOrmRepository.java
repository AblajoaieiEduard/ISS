package rest;

import Entities.Angajat;
import Entities.Sef;
import interfaces.SefRepository;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import java.util.List;

public class SefOrmRepository implements SefRepository {
    private static SessionFactory sessionFactory;

    static void initialize() {
        // A SessionFactory is set up once for an application!
        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .configure() // configures settings from hibernate.cfg.xml
                .build();
        try {
            sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
        }
        catch (Exception e) {
            System.err.println("Exceptie "+e);
            StandardServiceRegistryBuilder.destroy( registry );
        }
    }

    static void close() {
        if ( sessionFactory != null ) {
            sessionFactory.close();
        }
    }

    public SefOrmRepository() {
        initialize();
    }

    @Override
    public Sef findSef(String name) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                String select = "select Sefi.* from Sefi where nume="
                        + "'"
                        + name
                        + "'";
               Sef sef =
                        session.createNativeQuery(select, Sef.class)
                                .setMaxResults(1)
                                .uniqueResult();

                tx.commit();
                return sef;
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
        return null;
    }

    @Override
    public Sef findOne(Integer integer) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                Sef sef =
                        session.createNativeQuery("select Sefi.* from Sefi where id=" + integer, Sef.class)
                                .setMaxResults(1)
                                .uniqueResult();

                tx.commit();
                return sef;
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
        return null;
    }

    @Override
    public List<Sef> findAll() {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                List<Sef> sef =
                        session.createNativeQuery("select Sefi.* from Sefi", Sef.class)
                                .list();

                tx.commit();
                return sef;
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
        return null;
    }

    @Override
    public Sef save(Sef entity) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                Integer id = (Integer)  session.save(entity);
                tx.commit();
                return findOne(id);
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
        return null;
    }

    @Override
    public Sef delete(Integer integer) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();

                Sef crit = session.createNativeQuery("select Sefi.* from Sefi where id=" + integer, Sef.class)
                        .setMaxResults(1)
                        .uniqueResult();
                session.delete(crit);
                tx.commit();
                return crit;
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
        return null;
    }

    @Override
    public Sef update(Sef entity) {
        try(Session session = sessionFactory.openSession()){
            Transaction tx=null;
            try{
                tx = session.beginTransaction();
                Sef sef = session.load( Sef.class, entity.getId());


                sef.setUser(entity.getUser());
                sef.setParola(entity.getParola());

                //session.update(message);
                tx.commit();
                return sef;

            } catch(RuntimeException ex){
                if (tx!=null)
                    tx.rollback();
            }
        }
        return null;
    }

    @Override protected void finalize() throws Throwable {
        close();
        super.finalize();
    }
}
