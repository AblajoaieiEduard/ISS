package rest;

import Entities.Angajat;
import Entities.Sarcina;
import Entities.Sef;
import Entities.StareSarcina;
import interfaces.AngajatRepository;
import interfaces.SarcinaRepository;
import interfaces.SefRepository;
import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("")
public class GreatController {
    @Autowired
    private AngajatRepository angajatRepository;

    @Autowired
    private SefRepository sefRepository;

    @Autowired
    private SarcinaRepository sarcinaRepository;

    @RequestMapping(value = "/angajati", method = RequestMethod.GET)
    public List<Angajat> getAllAngajati(){
        return angajatRepository.findAll();
    }

    @RequestMapping(value="/angajati/{id}", method= RequestMethod.GET)
    public ResponseEntity<?> getAngajatById(@PathVariable Integer id){
        Angajat angajat = angajatRepository.findOne(id);
        if(angajat == null)
            return new ResponseEntity<String>("Entities.Angajat negasit", HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<Angajat>(angajat, HttpStatus.OK);
    }

    @RequestMapping(value="/login", method = RequestMethod.POST)
    public ResponseEntity<?> login(@RequestParam(value="nume", defaultValue = "") String nume,
                                   @RequestParam(value="parola", defaultValue = "") String parola){
        List<Angajat> angajati = angajatRepository.findAngajat(nume);
        for(Angajat angajat: angajati){
            if(angajat.getParola().equals(parola))
                return new ResponseEntity<Angajat>(angajati.get(0), HttpStatus.OK);
        }
        Sef sef = sefRepository.findSef(nume);
        if(sef.getParola().equals(parola)) {
            sef.setUser("Sef " + sef.getUser());
            return new ResponseEntity<Sef>(sef, HttpStatus.OK);

        }
        return new ResponseEntity<String>("Entities.Angajat negasit", HttpStatus.NOT_FOUND);
    }

    @RequestMapping(value="/sarcini", method = RequestMethod.GET)
    public List<Sarcina> getSarcini(){
        return sarcinaRepository.findAll();
    }

    @RequestMapping(value="/sarcini/{id}", method = RequestMethod.PUT)
    public ResponseEntity<Sarcina> updateStare(@RequestBody Sarcina sarcina){
        Sarcina s = sarcinaRepository.update(sarcina);
        return new ResponseEntity<Sarcina>(s, HttpStatus.OK);
    }

    @RequestMapping(value="/sarcini", method = RequestMethod.POST)
    public ResponseEntity<Sarcina> addSarcina(@RequestBody Sarcina sarcina){
        sarcinaRepository.save(sarcina);
        return new ResponseEntity<Sarcina>(sarcina, HttpStatus.OK);
    }
}
