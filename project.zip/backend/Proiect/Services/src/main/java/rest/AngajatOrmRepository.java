package rest;

import Entities.Angajat;
import interfaces.AngajatRepository;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class AngajatOrmRepository implements AngajatRepository {
    private static SessionFactory sessionFactory;

    static void initialize() {
        // A SessionFactory is set up once for an application!
        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .configure() // configures settings from hibernate.cfg.xml
                .build();
        try {
            sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
        }
        catch (Exception e) {
            System.err.println("Exceptie "+e);
            StandardServiceRegistryBuilder.destroy( registry );
        }
    }

    static void close() {
        if ( sessionFactory != null ) {
            sessionFactory.close();
        }
    }

    public AngajatOrmRepository() {
        initialize();
    }
    @Override
    public List<Angajat> findAngajat(String name) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                String select = "select Angajati.* from Angajati where nume="
                        + "'"
                        + name
                        + "'";
                List<Angajat> angajati =
                        session.createNativeQuery(select, Angajat.class)
                                .list();

                tx.commit();
                return angajati;
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
        return null;
    }

    @Override
    public Angajat findOne(Integer integer) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                Angajat angajat =
                        session.createNativeQuery("select Angajati.* from Angajati where id=" + integer, Angajat.class)
                                .setMaxResults(1)
                                .uniqueResult();

                tx.commit();
                return angajat;
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
        return null;
    }

    @Override
    public List<Angajat> findAll() {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                List<Angajat> angajati =
                        session.createNativeQuery("select Angajati.* from Angajati", Angajat.class)
                                .list();

                tx.commit();
                return angajati;
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
        return null;
    }

    @Override
    public Angajat save(Angajat entity) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                Integer id = (Integer)  session.save(entity);
                tx.commit();
                return findOne(id);
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
        return null;
    }

    @Override
    public Angajat delete(Integer integer) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();

                Angajat crit = session.createNativeQuery("select Angajati.* from Angajati where id=" + integer, Angajat.class)
                        .setMaxResults(1)
                        .uniqueResult();
                session.delete(crit);
                tx.commit();
                return crit;
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
        return null;
    }

    @Override
    public Angajat update(Angajat entity) {
        try(Session session = sessionFactory.openSession()){
            Transaction tx=null;
            try{
                tx = session.beginTransaction();
                Angajat angajat = session.load( Angajat.class, entity.getId());


                angajat.setUser(entity.getUser());
                angajat.setParola(entity.getParola());

                //session.update(message);
                tx.commit();
                return angajat;

            } catch(RuntimeException ex){
                if (tx!=null)
                    tx.rollback();
            }
        }
        return null;
    }

    @Override protected void finalize() throws Throwable {
        close();
        super.finalize();
    }
}
