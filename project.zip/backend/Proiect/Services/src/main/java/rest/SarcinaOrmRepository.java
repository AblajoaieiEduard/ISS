package rest;

import Entities.Angajat;
import Entities.Sarcina;
import Entities.SarcinaAngajat;
import interfaces.SarcinaAngajatRepository;
import interfaces.SarcinaRepository;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class SarcinaOrmRepository implements SarcinaRepository {
    private static SessionFactory sessionFactory;

    @Autowired
    SarcinaAngajatRepository sarcinaAngajatRepository;

    static void initialize() {
        // A SessionFactory is set up once for an application!
        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .configure() // configures settings from hibernate.cfg.xml
                .build();
        try {
            sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
        }
        catch (Exception e) {
            System.err.println("Exceptie "+e);
            StandardServiceRegistryBuilder.destroy( registry );
        }
    }

    static void close() {
        if ( sessionFactory != null ) {
            sessionFactory.close();
        }
    }

    public SarcinaOrmRepository() {
        initialize();
    }


    @Override
    public Sarcina findOne(Integer integer) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                Sarcina sarcina =
                        session.createNativeQuery("select Sarcini.* from Sarcini where id=" + integer, Sarcina.class)
                                .setMaxResults(1)
                                .uniqueResult();
                List<Integer> aux = sarcinaAngajatRepository.getAllForSarcina(sarcina.getId());
                sarcina.setAngajati(aux);
                tx.commit();
                return sarcina;
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
        return null;
    }

    @Override
    public List<Sarcina> findAll() {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                List<Sarcina> sarcini =
                        session.createNativeQuery("select Sarcini.* from Sarcini", Sarcina.class)
                                .list();
                sarcini.forEach(System.out::println);
                sarcini.forEach((Sarcina sarcina)->{
                    List<Integer> aux = sarcinaAngajatRepository.getAllForSarcina(sarcina.getId());
                    sarcina.setAngajati(aux);
                });
                tx.commit();
                return sarcini;
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
        return null;
    }

    @Override
    public Sarcina save(Sarcina entity) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                Integer id = (Integer)  session.save(entity);
                tx.commit();
                return findOne(id);
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
        return null;
    }

    @Override
    public Sarcina delete(Integer integer) {
        try(Session session = sessionFactory.openSession()) {
            Transaction tx = null;
            try {
                tx = session.beginTransaction();

                Sarcina crit = session.createNativeQuery("select Sarcini.* from Sarcini where id=" + integer, Sarcina.class)
                        .setMaxResults(1)
                        .uniqueResult();
                session.delete(crit);
                tx.commit();
                return crit;
            } catch (RuntimeException ex) {
                if (tx != null)
                    tx.rollback();
            }
        }
        return null;
    }

    @Override
    public Sarcina update(Sarcina entity) {
        try(Session session = sessionFactory.openSession()){
            Transaction tx=null;
            try{
                tx = session.beginTransaction();
                Sarcina sarcina = session.load( Sarcina.class, entity.getId());


                sarcina.setStare(entity.getStare());

                session.update(sarcina);
                tx.commit();
                return entity;

            } catch(RuntimeException ex){
                if (tx!=null)
                    tx.rollback();
            }
        }
        return null;
    }

    @Override protected void finalize() throws Throwable {
        close();
        super.finalize();
    }
}
