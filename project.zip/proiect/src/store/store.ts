import {
	applyMiddleware,
	combineReducers,
	createStore,
	Middleware,
} from "redux";
import { composeWithDevTools } from "redux-devtools-extension";
import thunk from "redux-thunk";
import { userInitialState, UserState, userReducer } from "./users/userReducer";

export type RootState = {
	userState: UserState;
};

export const initialRootState: RootState = {
	userState: userInitialState,
};

export const rootReducer = combineReducers({
	userState: userReducer,
});

const middleWares: Middleware[] = [thunk];

const store = createStore(
	rootReducer,
	initialRootState as any,
	composeWithDevTools(applyMiddleware(...middleWares))
);

export default store;
