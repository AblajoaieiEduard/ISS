import { Action } from "redux";
import { ThunkAction } from "redux-thunk";
import { getAngajati, login } from "../../api";
import {
	getAngajatiFailure,
	getAngajatiStart,
	getAngajatiSuccess,
	loginFailure,
	loginStart,
	loginSuccess,
} from "./actions";
import { UserState } from "./userReducer";

export const loginThunk =
	(
		name: string,
		password: string
	): ThunkAction<void, UserState, unknown, Action<string>> =>
	async (dispatch) => {
		dispatch(loginStart());

		try {
			const user = await login(name, password);
			if (user !== undefined) {
				dispatch(loginSuccess(user));
			} else dispatch(loginFailure("Nu a fost gasit"));
		} catch (error) {
			console.log(error);
		}
	};

export const getAngajatiThunk =
	(): ThunkAction<void, UserState, unknown, Action<string>> =>
	async (dispatch) => {
		dispatch(getAngajatiStart());

		try {
			const users = await getAngajati();
			if (users !== undefined) {
				dispatch(getAngajatiSuccess(users));
			} else
				dispatch(getAngajatiFailure("N-a mers request-ul pentru angajati"));
		} catch (error) {
			console.log(error);
		}
	};
