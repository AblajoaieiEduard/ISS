import { Utilizator } from "../../model/utilizator";
import {
	ActionTypes,
	Delogare,
	GetAngajatiFailure,
	GetAngajatiStart,
	GetAngajatiSuccess,
	LoginFailure,
	LoginStart,
	LoginSuccess,
} from "./types";

export const loginStart = (): LoginStart => {
	return {
		type: ActionTypes.LOGIN_START,
	};
};

export const loginSuccess = (user: Utilizator): LoginSuccess => {
	return {
		type: ActionTypes.LOGIN_SUCCESS,
		user,
	};
};

export const loginFailure = (error: string): LoginFailure => {
	return {
		type: ActionTypes.LOGIN_FAILURE,
		error,
	};
};

export const getAngajatiStart = (): GetAngajatiStart => {
	return {
		type: ActionTypes.GET_ANGAJATI_START,
	};
};

export const getAngajatiSuccess = (users: Utilizator[]): GetAngajatiSuccess => {
	return {
		type: ActionTypes.GET_ANGAJATI_SUCCESS,
		users,
	};
};

export const getAngajatiFailure = (error: string): GetAngajatiFailure => {
	return {
		type: ActionTypes.GET_ANGAJATI_FAILURE,
		error,
	};
};

export const delogare = (): Delogare => {
	return {
		type: ActionTypes.DELOGARE,
	};
};
