import { Utilizator } from "../../model/utilizator";
import { loginFailure, loginSuccess } from "./actions";

export enum ActionTypes {
	LOGIN_START = "LOGIN_START",
	LOGIN_SUCCESS = "LOGIN_SUCCESS",
	LOGIN_FAILURE = "LOGIN_FAILURE",
	GET_ANGAJATI_START = "GET_ANGAJATI_START",
	GET_ANGAJATI_SUCCESS = "GET_ANGAJATI_SUCCESS",
	GET_ANGAJATI_FAILURE = "GET_ANGAJATI_FAILURE",
	DELOGARE = "DELOGARE",
}

export type Delogare = {
	type: ActionTypes.DELOGARE;
};

export type LoginStart = {
	type: ActionTypes.LOGIN_START;
};

export type LoginSuccess = {
	type: ActionTypes.LOGIN_SUCCESS;
	user: Utilizator;
};

export type LoginFailure = {
	type: ActionTypes.LOGIN_FAILURE;
	error: string;
};

export type GetAngajatiStart = {
	type: ActionTypes.GET_ANGAJATI_START;
};

export type GetAngajatiSuccess = {
	type: ActionTypes.GET_ANGAJATI_SUCCESS;
	users: Utilizator[];
};

export type GetAngajatiFailure = {
	type: ActionTypes.GET_ANGAJATI_FAILURE;
	error: string;
};

export type UserAction =
	| LoginStart
	| LoginSuccess
	| LoginFailure
	| GetAngajatiStart
	| GetAngajatiSuccess
	| GetAngajatiFailure
	| Delogare;
