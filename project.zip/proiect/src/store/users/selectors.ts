import { createSelector } from "reselect";
import { RootState } from "../store";

export const getUserState = (state: RootState) => state.userState;

export const getCurrentUser = createSelector(
	getUserState,
	(userState) => userState.currentUser
);

export const getLoginError = createSelector(
	getUserState,
	(userState) => userState.loginError
);

export const getUsers = createSelector(
	getUserState,
	(userState) => userState.users
);
