import { Utilizator } from "../../model/utilizator";
import { ActionTypes, UserAction } from "./types";

export type UserState = {
	currentUser?: Utilizator;
	loginLoading: boolean;
	loginError?: string;
	getAngajatiLoading: boolean;
	users: Utilizator[];
	getAngajatiError?: string;
};

export const userInitialState: UserState = {
	loginLoading: false,
	currentUser: undefined,
	loginError: undefined,
	getAngajatiLoading: false,
	users: [],
	getAngajatiError: undefined,
};

export const userReducer = (
	state: UserState = userInitialState,
	action: UserAction
) => {
	switch (action.type) {
		case ActionTypes.LOGIN_START:
			return {
				...state,
				loginLoading: true,
			};
		case ActionTypes.LOGIN_SUCCESS:
			return {
				...state,
				currentUser: action.user,
				loginLoading: false,
			};
		case ActionTypes.LOGIN_FAILURE:
			return {
				...state,
				loginError: action.error,
				loginLoading: false,
			};
		case ActionTypes.GET_ANGAJATI_START:
			return {
				...state,
				getAngajatiLoading: true,
			};
		case ActionTypes.GET_ANGAJATI_SUCCESS:
			return {
				...state,
				users: action.users,
				getAngajatiLoading: false,
			};
		case ActionTypes.GET_ANGAJATI_FAILURE:
			return {
				...state,
				getAngajatiError: action.error,
				getAngajatiLoading: false,
			};
		case ActionTypes.DELOGARE:
			return {
				...state,
				currentUser: undefined,
			};
		default:
			return state;
	}
};
