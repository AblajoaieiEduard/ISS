import React from "react";
import logo from "./logo.svg";
import "./App.css";
import { Card, Grid, Typography } from "@material-ui/core";
import { Provider } from "react-redux";
import LoginPage from "./features/LoginPage";
import { Switch, Route, BrowserRouter as Router } from "react-router-dom";
import EmployeePage from "./features/EmployeePage";
import store from "./store/store";
import BossPage from "./features/BossPage";

function App() {
	return (
		<Provider store={store}>
			<Router>
				<Switch>
					<Route exact path="/employee/:id">
						<EmployeePage />
					</Route>
					<Route exact path="/sef">
						<BossPage />
					</Route>
					<Route path="/">
						<LoginPage />
					</Route>
				</Switch>
			</Router>
		</Provider>
	);
}

export default App;
