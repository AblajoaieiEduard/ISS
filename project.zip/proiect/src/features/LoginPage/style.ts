import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles(() => ({
	container: {
		width: "100vw",
		height: "100vh",
		backgroundColor: "pink",
	},
	root: {
		maxWidth: 500,
		minWidth: 400,
		marginBottom: "40vh",
		padding: 10,
	},
	button: {
		marginTop: "20px",
	},
	input: {
		width: "100%",
	},
}));
