import {
	Button,
	Card,
	CardActions,
	FormControl,
	Grid,
	Input,
	InputLabel,
	TextField,
} from "@material-ui/core";
import axios, { AxiosError, AxiosResponse } from "axios";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router";
import { login } from "../../api";
import { Utilizator } from "../../model/utilizator";
import { getCurrentUser, getLoginError } from "../../store/users/selectors";
import { loginThunk } from "../../store/users/thunkActions";
import { useStyles } from "./style";

const LoginPage = () => {
	const classes = useStyles();
	const [name, setName] = useState("");
	const [password, setPassword] = useState("");
	const history = useHistory();
	const currentUser = useSelector(getCurrentUser);
	const error = useSelector(getLoginError);
	const dispatch = useDispatch();

	const handleLogin = () => {
		try {
			dispatch(loginThunk(name, password));
		} catch (error) {
			console.log(error);
			console.log("Sttaaaaaaaaaaart");
		}
	};

	useEffect(() => {
		if (currentUser)
			if (currentUser.user.startsWith("Sef ")) {
				history.push(`sef`);
			} else history.push(`employee/${currentUser!.id}`);
	}, [currentUser]);

	return (
		<Grid
			container
			justify="center"
			alignItems="center"
			className={classes.container}
		>
			<Card variant="outlined" className={classes.root}>
				<Grid
					item
					container
					spacing={5}
					direction="column"
					justify="center"
					alignItems="center"
				>
					<Grid item className={classes.input}>
						<TextField
							fullWidth
							label="Nume"
							value={name}
							onChange={(e) => setName(e.target.value)}
						/>
					</Grid>
					<Grid item className={classes.input}>
						<TextField
							fullWidth
							label="Parola"
							value={password}
							type="password"
							onChange={(e) => setPassword(e.target.value)}
						/>
					</Grid>
				</Grid>

				<Button
					className={classes.button}
					variant="contained"
					size="large"
					onClick={handleLogin}
				>
					Login
				</Button>
			</Card>
		</Grid>
	);
};

export default LoginPage;
