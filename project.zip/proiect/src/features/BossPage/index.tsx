import {
	Button,
	Card,
	Checkbox,
	Dialog,
	Grid,
	TextField,
	Typography,
} from "@material-ui/core";
import { ChangeEvent, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router";
import { addSarcina } from "../../api";
import { Sarcina } from "../../model/Sarcina";
import { Utilizator } from "../../model/utilizator";
import { delogare } from "../../store/users/actions";
import { getCurrentUser, getUsers } from "../../store/users/selectors";
import { getAngajatiThunk } from "../../store/users/thunkActions";
import { useStyles } from "./styles";

const BossPage = () => {
	const classes = useStyles();
	const employees = useSelector(getUsers);
	const [open, setOpen] = useState(false);
	const dispatch = useDispatch();
	const history = useHistory();
	const [selected, setSelected] = useState<Utilizator[]>([]);
	const [descriere, setDescriere] = useState("");
	const [date, setDate] = useState<String>();
	const currentUser = useSelector(getCurrentUser);

	useEffect(() => {
		if (employees.length !== 0) console.log("yay");
	}, [employees]);

	useEffect(() => {
		if (employees.length === 0) dispatch(getAngajatiThunk());
	});

	const handleDelogare = () => {
		history.push("/");
		dispatch(delogare());
	};

	const handleAdauga = () => {
		const sarcina: Sarcina = {
			id: "0",
			stare: "ALOCATA",
			descriere: descriere,
			deadline: new Date().toString(),
			// deadline: date ? date : new String(""),
			idSef: currentUser ? currentUser.id.toString() : "",
			angajati: selected.map((employee: Utilizator) => employee.id.toString()),
		};
		addSarcina(sarcina);
	};
	return (
		<>
			<Grid container alignItems="center" direction="column" spacing={3}>
				<Grid item>
					<Typography className={classes.title}>
						Pagina sefului adica eu c:
					</Typography>
				</Grid>
				<Grid item>
					{employees && (
						<Card className={classes.card}>
							{employees.map((employee: Utilizator) => (
								<Grid item container alignItems="center">
									<Grid item xs={9}>
										<Typography>{employee.id + "." + employee.user}</Typography>
									</Grid>
									<Grid item xs={2}>
										<Checkbox
											onChange={(
												event: ChangeEvent<HTMLInputElement>,
												checked: boolean
											) => {
												if (checked) setSelected([...selected, employee]);
												else
													setSelected(
														selected.filter(
															(emp: Utilizator) => emp !== employee
														)
													);
											}}
										/>
									</Grid>
								</Grid>
							))}
						</Card>
					)}
				</Grid>
				<Grid item>
					<Button
						color="secondary"
						variant="contained"
						onClick={() => setOpen(true)}
						disabled={selected.length === 0}
					>
						Asigneaza task
					</Button>
				</Grid>
				<Grid item>
					<Button color="primary" onClick={handleDelogare}>
						Delogare
					</Button>
				</Grid>
			</Grid>
			<Dialog open={open} onClose={() => setOpen(false)} fullScreen>
				<Grid container direction="column" justify="center" alignItems="center">
					<Grid item>
						<TextField
							id="outlined-multiline-static"
							label="Descriere"
							multiline
							rows={4}
							placeholder="Aici scrii detalii :)"
							variant="outlined"
							fullWidth
							className={classes.descriere}
							value={descriere}
							onChange={(
								event: ChangeEvent<HTMLTextAreaElement | HTMLInputElement>
							) => setDescriere(event.target.value)}
						/>
					</Grid>
					<Grid item>
						<form className={classes.container} noValidate>
							<TextField
								id="datetime-local"
								label="Deadline"
								type="datetime-local"
								className={classes.textField}
								InputLabelProps={{
									shrink: true,
								}}
								value={date}
								onChange={(
									event: ChangeEvent<HTMLTextAreaElement | HTMLInputElement>
								) => {
									setDate(event.target.value);
								}}
								fullWidth
							/>
						</form>
					</Grid>
					<Grid item>
						<Button
							color="primary"
							variant="contained"
							className={classes.adaugaButton}
							disabled={
								descriere.length === 0 ||
								date === undefined ||
								date?.length === 0
							}
							onClick={handleAdauga}
						>
							Adauga Sarcina
						</Button>
					</Grid>
					<Grid item>
						<Button
							color="primary"
							className={classes.adaugaButton}
							onClick={() => setOpen(false)}
						>
							Anuleaza
						</Button>
					</Grid>
				</Grid>
			</Dialog>
		</>
	);
};

export default BossPage;
