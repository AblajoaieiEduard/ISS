import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles(() => ({
	title: {
		fontSize: "50px",
		fontFamily: "Georgia, serif",
		margin: 0,
		padding: 0,
	},
	card: {
		width: "200px",
	},
	container: {
		display: "flex",
		flexWrap: "wrap",
	},
	textField: {
		margin: "20px",
		width: 400,
	},
	descriere: {
		marginTop: "50px",
		width: 400,
	},
	dialog: {
		width: "100%",
	},
	adaugaButton: {
		width: 400,
	},
}));
