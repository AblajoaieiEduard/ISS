import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles(() => ({
	title: {
		fontSize: "50px",
		fontFamily: "Georgia, serif",
		margin: 0,
		padding: 0,
	},
	inputfield: {
		width: "150px",
	},
}));
