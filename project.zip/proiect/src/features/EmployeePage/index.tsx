import {
	Button,
	FormControl,
	Grid,
	InputLabel,
	MenuItem,
	Select,
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableRow,
	Typography,
} from "@material-ui/core";
import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useHistory, useLocation } from "react-router-dom";
import { changeStare, getEmployeeById, getSarcini } from "../../api";
import { Sarcina } from "../../model/Sarcina";
import { Utilizator } from "../../model/utilizator";
import { delogare } from "../../store/users/actions";
import { useStyles } from "./styles";

const EmployeePage = () => {
	const location = useLocation();
	const classes = useStyles();
	const [employee, setEmployee] = useState({ id: 0, user: "ion", parola: "" });
	const [sarcini, setSarcini] = useState<Sarcina[]>([]);
	const [stari, setStari] = useState<String[]>([]);
	const dispatch = useDispatch();
	const history = useHistory();

	const computeId = () => {
		const path = location.pathname;
		return path.slice(path.lastIndexOf("/") + 1, path.length);
	};

	const computeEmployee = async () => {
		return await getEmployeeById(parseInt(computeId()));
	};

	const handleDelogare = () => {
		history.push("/");
		dispatch(delogare());
	};

	useEffect(() => {
		computeEmployee().then((res: Utilizator) => {
			console.log(res);
			setEmployee(res);
		});
	}, []);

	useEffect(() => {
		getSarcini().then((res: Sarcina[]) => {
			setSarcini(res);
			let aux: String[] = [];
			res.map((sarcina: Sarcina) => aux.push(sarcina.stare));
			setStari(aux);
			console.log(aux);
		});
	}, []);

	return (
		<Grid>
			{employee && stari.length !== 0 ? (
				<Grid container alignItems="center" direction="column" spacing={3}>
					<Grid item>
						<Typography className={classes.title}>Sarcini:</Typography>
					</Grid>
					<Grid item>
						<Table>
							<TableHead>
								<TableRow>
									<TableCell>ID</TableCell>
									<TableCell component="th">Descriere</TableCell>
									<TableCell>Echipa</TableCell>
									<TableCell>Stare</TableCell>
									<TableCell>Deadline</TableCell>
								</TableRow>
							</TableHead>
							<TableBody>
								{sarcini.map((sarcina: Sarcina, index) => {
									return (
										<TableRow>
											<TableCell>{sarcina.id}</TableCell>
											<TableCell>{sarcina.descriere}</TableCell>
											<TableCell>{sarcina.angajati}</TableCell>
											<TableCell>
												<InputLabel id="demo-simple-select-filled-label">
													Stare
												</InputLabel>
												<Select
													className={classes.inputfield}
													labelId="demo-simple-select-filled-label"
													id="demo-simple-select-filled"
													value={stari[index]}
													onChange={(
														e: React.ChangeEvent<{
															name?: string | undefined;
															value: unknown;
														}>
													) => {
														changeStare({
															...sarcina,
															stare: e.target.value as string,
														});
														let aux: String[] = [];
														sarcini.map((sarcina: Sarcina, secondIndex) => {
															if (secondIndex === index)
																aux.push(e.target.value as string);
															else aux.push(sarcina.stare);
														});
														setStari(aux);
													}}
												>
													<MenuItem value="ALOCATA">ALOCATA</MenuItem>
													<MenuItem value="PROGRES">PROGRES</MenuItem>
													<MenuItem value="FINALIZATA">FINALIZATA</MenuItem>
												</Select>
											</TableCell>
											<TableCell>{sarcina.deadline}</TableCell>
										</TableRow>
									);
								})}
							</TableBody>
						</Table>
					</Grid>
					<Grid item>
						<Button
							variant="contained"
							color="primary"
							onClick={handleDelogare}
						>
							Delogare
						</Button>
					</Grid>
				</Grid>
			) : (
				<Typography>Mai asteptam putin c:</Typography>
			)}
		</Grid>
	);
};

export default EmployeePage;
