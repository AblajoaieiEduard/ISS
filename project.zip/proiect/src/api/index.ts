import axios, { AxiosError, AxiosResponse } from "axios";
import { Sarcina } from "../model/Sarcina";
import { Utilizator } from "../model/utilizator";

const axiosInstance = axios.create({ baseURL: "http://localhost:8080/" });

export const login = (nume: string, parola: string): Promise<Utilizator> => {
	return axiosInstance
		.post(`/login?nume=${nume}&parola=${parola}`)
		.then((res: AxiosResponse) => res.data)
		.catch((error: AxiosError) => {
			return error;
		});
};

export const getEmployeeById = (id: number): Promise<Utilizator> => {
	return axiosInstance
		.get(`angajati/${id}`)
		.then((res: AxiosResponse) => res.data)
		.catch((error: AxiosError) => {
			console.log(error);
		});
};

export const getAngajati = (): Promise<Utilizator[]> => {
	return axiosInstance
		.get("angajati")
		.then((res: AxiosResponse) => res.data)
		.catch((error: AxiosError) => {
			console.log(error);
		});
};

export const getSarcini = (): Promise<Sarcina[]> => {
	return axiosInstance
		.get("sarcini")
		.then((res: AxiosResponse) => res.data)
		.catch((error: AxiosError) => {
			console.log(error);
		});
};

export const changeStare = (sarcina: Sarcina): Promise<Sarcina[]> => {
	return axiosInstance
		.put(`sarcini/${sarcina.id}`, sarcina)
		.then((res: AxiosResponse) => res.data)
		.catch((error: AxiosError) => {
			console.log(error);
		});
};

export const addSarcina = (sarcina: Sarcina): Promise<Sarcina> => {
	return axiosInstance
		.post(`sarcini`, sarcina)
		.then((res: AxiosResponse) => res.data)
		.catch((error: AxiosError) => {
			console.log(error);
		});
};
