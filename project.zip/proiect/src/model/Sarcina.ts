export type Sarcina = {
	id: String;
	stare: String;
	descriere: String;
	deadline: String;
	idSef: String;
	angajati: String[];
};
