export type Utilizator = {
	id: number;
	user: string;
	parola: string;
};
